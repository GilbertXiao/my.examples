drop database greenfield;

create database greenfield;

use greenfield;

create table User(
   UserID int(10) unsigned NOT NULL auto_increment,
   FirstName varchar(40),
   LastName varchar(40),
   SSN varchar(40),
   Address1 varchar(40),
   Address2 varchar(40),
   PhoneNumber varchar(40),
   City varchar(40),
   State varchar(40),
   ZipCode varchar(40),
   Primary Key (UserID)
) ENGINE=InnoDB charset=latin1;

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode) 
values ('First0', 'Last0', '000-00-0000', '0 Street', 'Apt 0', '000-000-0000', 'City 0', 'State 0', '00000');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode) 
values ('First1', 'Last1', '111-11-1111', '1 Street', 'Apt 1', '111-111-1111', 'City 1', 'State 1', '11111');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode)
values ('First2', 'Last2', '222-22-2222', '2 Street', 'Apt 2', '222-222-2222', 'City 2', 'State 2', '22222');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode) 
values ('First3', 'Last3', '333-33-3333', '3 Street', 'Apt 3', '333-333-3333', 'City 3', 'State 3', '33333');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode)
values ('First4', 'Last4', '444-44-4444', '4 Street', 'Apt 4', '444-444-4444', 'City 4', 'State 4', '44444');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode) 
values ('First5', 'Last5', '555-55-5555', '5 Street', 'Apt 5', '555-555-5555', 'City 5', 'State 5', '55555');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode)
values ('First6', 'Last6', '666-66-6666', '6 Street', 'Apt 6', '666-666-6666', 'City 6', 'State 6', '66666');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode) 
values ('First7', 'Last7', '777-77-7777', '7 Street', 'Apt 7', '777-777-7777', 'City 7', 'State 7', '77777');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode)
values ('First8', 'Last8', '888-88-8888', '8 Street', 'Apt 8', '888-888-8888', 'City 8', 'State 8', '88888');

Insert into User (FirstName, LastName, SSN, Address1, Address2, PhoneNumber, City, State, ZipCode) 
values ('First9', 'Last9', '999-99-9999', '9 Street', 'Apt 9', '999-999-9999', 'City 9', 'State 9', '99999');