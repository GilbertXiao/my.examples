
class CheckInt
{
	public static void main(String args[])
	{
		System.out.println("in main"); 
	}
}
