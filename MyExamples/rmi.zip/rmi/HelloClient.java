
import demo.*;
import java.rmi.*;

class HelloClient
{
	public static void main(String[] args) throws Exception
	{
		Remote ref = Naming.lookup("hello");
		Hello h = (Hello)ref;
		String result = h.sayHello(args[0]);
		System.out.println(result);
	}
}