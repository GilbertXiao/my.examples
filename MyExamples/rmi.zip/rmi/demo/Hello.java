
package demo;

public interface Hello extends java.rmi.Remote
{
	String sayHello(String s) 
			throws java.rmi.RemoteException;
}