
package demo;

public class HelloImpl implements Hello
{
	private int i;

	public HelloImpl() 
	{}

	public String sayHello(String s)
	{
		i++;

		return 
		 "Hello " +s+ " yours is " +i+ " request";
	}
}