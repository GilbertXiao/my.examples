
public class Employee implements Serializable
{
	int    empno;
	String ename;
	float  sal;
}

public class EmployeeNotFoundException 
extends Exception
{
}

public interface Manager extends Remote
{
	public void addEmployee( Employee empObj )
	throws RemoteException;

	public Employee findEmployee( int empno )
	throws RemoteException,EmployeeNotFoundException;
	
	public void removeEmployee( int empno)
	throws RemoteException,EmployeeNotFoundException;

	public Employee[] getAllEmployees() 
	throws RemoteException;

	public void updateSalary
							(int empno, float newSalary) 
							throws RemoteException,
							EmployeeNotFoundException;
}
