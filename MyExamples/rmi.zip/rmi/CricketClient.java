import clientcricket.*;

public class CricketClient
{
	public static void main(String args[])
	throws Exception
	{
		new ClientCricketImpl();
	}
}
