package cricket;

import java.rmi.*;
import clientcricket.*;
/*
	This interface provide single operation for registering client with remote object.
*/
public interface ServerCricketInterface 
extends Remote
{
	void registerMe(ClientCricketInterface cref)
	 throws RemoteException;
}
