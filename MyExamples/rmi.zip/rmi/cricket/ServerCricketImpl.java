package cricket;

import clientcricket.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.rmi.*;
import java.rmi.server.*;

/*
	This class represents a UI for updating new score.
	This class also provide business logic for registring client
	and updating new score.
*/
public class ServerCricketImpl
extends Frame implements 
ServerCricketInterface,ActionListener
{
	Vector v;
	TextField tf;
	Button ok;
	
	/*
		Constructor exports the remote object and creates the UI.

	*/
	public ServerCricketImpl() throws RemoteException
	{
		UnicastRemoteObject.exportObject(this);

		setFont(new Font("Monospaced",Font.PLAIN,20));
		setSize(300,300);

		v = new Vector();
		tf = new TextField(20);
		ok = new Button(" Ok ");

		ok.addActionListener(this);

		setLayout(new FlowLayout());
		add(tf);
		add(ok);	
		setVisible(true);
	}

/*
	registerMe function registers the client with remote object
	@param cref represents client to be register.
*/
public void registerMe
(ClientCricketInterface cref) 
throws RemoteException
{
	v.addElement(cref);
}


public void actionPerformed(ActionEvent evt)
{
	if(evt.getSource() == ok)
	{	
		int score = Integer.parseInt(tf.getText());

		Enumeration e  = v.elements();
		// updates the new score to all clients.
		while(e.hasMoreElements())
		{
			Object o = e.nextElement();

			ClientCricketInterface c = 
						(ClientCricketInterface)o;
	
			try
			{
				c.newScore(score);
			}
			catch(Exception ex)
			{
				v.remove(c);
			}
		} // end of while
	}		// end of if
}			// end of method

}     // end of ServerCricketImpl