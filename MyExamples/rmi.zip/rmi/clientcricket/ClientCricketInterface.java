package clientcricket;

import java.rmi.*;

public interface ClientCricketInterface 
extends Remote
{
	void newScore(int a) throws RemoteException;
}
