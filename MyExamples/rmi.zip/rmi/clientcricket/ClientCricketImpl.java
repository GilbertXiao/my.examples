package clientcricket;
 
import cricket.*;
import java.awt.*;
import java.rmi.*;
import java.rmi.server.*;
/*
	This class represents a client which can be register with remote server
*/
public class ClientCricketImpl extends Frame 
implements ClientCricketInterface
{
	Label l;
	TextField tf;
	/*
		Constructor export the ClientCricketImpl object.
		And creates UI for viewing the latest score.
	*/
	public ClientCricketImpl()
	throws Exception
	{
		UnicastRemoteObject.exportObject(this);
		setSize(400,300);
		Remote r = Naming.lookup("cricket");

		ServerCricketInterface s = 
						(ServerCricketInterface)r;
		//registering client with remote server.
		s.registerMe(this);

		setFont(new Font("Monospaced",Font.PLAIN,20));
		l  = new Label("Score");
		tf = new TextField(20);

		setLayout(new FlowLayout());
		add(l);
		add(tf);
		setVisible(true);
	}
	
	/*
		newScore function is called by remote server for setting new score.
	*/
	public void newScore(int x) throws RemoteException
	{
		tf.setText( String.valueOf(x) );
	}
}