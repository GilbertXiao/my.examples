
import demo.*;
import java.rmi.*;
import java.rmi.server.*;

class HelloServer 
{
	public static void main(String[] args) 
	throws Exception
	{
		HelloImpl remoteObj = new HelloImpl();
		System.out.println("HelloImpl Created");

		UnicastRemoteObject.exportObject(remoteObj);
		System.out.println("HelloImpl Exported");

		Naming.rebind("hello", remoteObj);
		System.out.println("HelloImpl Binded");
	}
}