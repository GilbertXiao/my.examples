
import cricket.*;
import java.rmi.*;
/*
	This class creates a remote object and binds it in registry by name "create".
*/
public class CricketServer
{
	public static void main(String args[]) 
	throws Exception
	{
		ServerCricketImpl r = 
					new ServerCricketImpl();

		Naming.rebind("cricket",r);
		System.out.println("Object Ready");
	}
}