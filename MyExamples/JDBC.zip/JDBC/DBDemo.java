
import java.sql.*;
import java.util.*;
/**
	Class DBDemo creates a connection using JdbcOdbcDriver
*/
class DBDemo 
{
	public static void main(String[] args) throws Exception
	{
		String url = "jdbc:odbc:mydsn";
		Properties p = new Properties();
		p.put("user", "sa");
		p.put("password","dss");

		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

		Connection conn = 
			DriverManager.getConnection( url, p );

		System.out.println("Connection Established");

		conn.close();
	}
}