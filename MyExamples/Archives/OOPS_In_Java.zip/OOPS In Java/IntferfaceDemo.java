// A simple interface
interface I
{
	void show();
}
// classes A and B implementing the same interface
class A implements I
{
	public void show()
	{
		System.out.println("in show() of A");
	}
}
class B implements I
{
	public void show()
	{
		System.out.println("in show() of B");
	}
}



class InterfaceDemo
{
	public static void main(String args[])
	{
		I i = new B();
		// Type casting i to A
		A a = (A)i;
	}
}