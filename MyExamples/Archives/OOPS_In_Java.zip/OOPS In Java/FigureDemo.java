// An abstract class
abstract class Figure
{
	int d1;
	int d2;

	// constructor with arguments
	Figure(int a,int b)
	{
		d1 = a;
		d2 = b;
	}

	// abstract method
	abstract int area();

}

// inheriting the class
class Rectangle extends Figure
{
	// constructor
	Rectangle(int l,int w)
	{
		// calling the superclass constructor
		// this must be the first statement in subclass constructor
		super(l,w);
	}
	
	// returns the area
	int area()
	{
		return d1 * d2;
	}
}


class FigureDemo
{
	public static void main(String[] args) 
	{
		// creating the object of Rectangle class 
		Figure f = new Rectangle(2,4);
		// calling the function area
		System.out.println( f.area() );
	}
}
