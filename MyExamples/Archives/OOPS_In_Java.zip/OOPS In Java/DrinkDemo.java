// declares a simple interface
interface Drinkable
{
	void drink();
}

// classes implementing interface and overriding methods
class Tea implements Drinkable
{
	public void drink()
	{
		System.out.println("Here is your TEA");
	}
}

class Coffee implements Drinkable
{
	public void drink()
	{
		System.out.println("Here is your COFFEE");
	}
}

class SoftDrink implements Drinkable
{
	public void drink()
	{
		System.out.println("Here is your SoftDrink");
	}
}


class Canteen
{
	// static method which returns a drinkable instance w.r.t token
	static Drinkable getDrink(int token)
	{
		Drinkable t;
		switch(token)
		{
			case 1:
				t = new Tea();
				break;
			case 2:
				t = new Coffee();
				break;
			case 3:
				t = new SoftDrink();
				break;
			default:
				t = null;
				break;
		}
		return t;
	}	
}

class DrinkDemo 
{
	public static void main(String[] args) 
	{
		// parsing a string to int
		int token = Integer.parseInt(args[0]);

		// calls the static method with class name
		Drinkable d = Canteen.getDrink( token );
		
		// checks whether the object is created or not
		if(d != null)
			d.drink();
		else
			System.out.println("INVALID token");
	}
}
