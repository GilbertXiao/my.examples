
class A
{
	int x;

	// function returning object
	A  doubleValue()
	{
		return null;	
	}
}
class ReturnDemo
{
	public static void main(String[] args)
	{
		A a = new A();
		a.x = 10;
		A b = a.doubleValue();
		// displays 10
		System.out.println(a.x);
		// Throws NullPointerException
		System.out.println(b.x);
	}
}