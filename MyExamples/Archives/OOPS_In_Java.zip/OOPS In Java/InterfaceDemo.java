// simple interface example
interface I
{
	long show();
}

interface J 
{
	int show();
}

// Class implementing more than one interface
class A implements I,J
{
	public int show()
	{
		return 1;
	}
}

class InterfaceDemo
{
	public static void main(String args[])
	{
	}
}