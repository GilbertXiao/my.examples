// Example which shows abstract class and simple inheritence
// An abstract class
abstract class Animal
{
	// declaration of a method as abstract
	abstract void move();
}

// inheriting the class Animal
class Cat extends Animal
{
	// implementing the method defined in abstract class
	void move()
	{
		System.out.println("Cat moving");
	}
}

class Dog extends Animal
{
	// implementing the method defined in abstract class
	void move()
	{
		System.out.println("Dog moving");
	}
	// concrete methods are allowed in subclass		
	void bark()
	{
		System.out.println("Dog barking");		
	}
}
class Test
{
	// displays the behaviour of Dog
	public void showBehavior(Animal a)
	{
		// calling sub class method using superclass instance
		a.move();
		// checks whether the a is an instance of Dog class
		if(a instanceof Dog)
		{
			// type casting the instance
			Dog d = (Dog)a;
			d.bark();
		}
		
	}
}
class CastingDemo
{
	public static void main(String arg[])
	{
		String animal = arg[0];
		// checks whether the command line argument passed is cat ignoring case
		if(animal.equalsIgnoreCase("cat"))
		{
			//creates an object and calls the method
			new Cat().move();
		}
		// checks whether the command line argument passed is cat ignoring case
		else if(animal.equalsIgnoreCase("dog"))
		{
			Animal a = new Dog();
			Test t = new Test();
			t.showBehavior(a);
		}
	
	}
}