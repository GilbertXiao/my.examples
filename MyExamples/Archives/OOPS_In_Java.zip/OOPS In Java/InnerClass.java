
class A
{
	int x;
	void meth()
	{
		// this is a inner class
		class B
		{
			void show()
			{
				System.out.println(x);
			}
		}	
		// creating object of innerclass
		B b = new B();
		//calling method of innerclass
		b.show();
	}
	
	public static void main(String[] args) 
	{
		A a = new A();
		a.x = 10;
		a.meth();
	}
}
