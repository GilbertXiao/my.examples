
class A
{
	int z;
	void meth(A x)
	{
		x = new A();
		x.z = x.z*2;
	}
}
class PassByValueDemo
{
	public static void main(String[] args) 
	{
		A a = new A();
		a.z = 5;
		System.out.println( a.z );
		// passing object as parameter to a function
		a.meth( a );
		System.out.println( a.z );
	}
}