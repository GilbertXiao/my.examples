class A
{
	// invokes when object is passed
	A(Object o)
	{
		System.out.println("A(Object)");
	}
	// invokes when String is passed
	A(String s)
	{
		System.out.println("A(String)");
	}
}

class  Demo
{
	public static void main(String[] args) 
	{
		// null is string and (Object) type casts it to Object
		new A( (Object)null);
	}
}
