// A simple abstract class
abstract class Vehicle
{
	// abstract method declaration
	abstract void move();
}

// classes inheriting the Vehicle class
class Car extends Vehicle
{
	void move()
	{
		System.out.println("Car is moving");
	}
	void play()
	{
		System.out.println("Car Stereo is playing");
	}
	
	public String toString()
	{
		return "in Car class";
	}
}

class SportsCar extends Car
{
	void move()
	{
		System.out.println("SportsCar is moving");
	}
}

class Bike extends Vehicle
{
	void move()
	{
		System.out.println("Bike is moving");
	}
}


class  InheritDemo
{
	public static void main(String[] args) 
	{
		// creating instance of Point
		Point p = new Point(2,4);
		// p calls p.toString() 
		// concatinates "hello" with message returned by toString()
		String str = "Hello " + p;
		System.out.println( str );

	}
}