
class Vehicle
{
}

class Car extends Vehicle
{
}

class SportsCar extends Car
{
}

class Bike extends Vehicle
{
}

class TypecastDemo 
{
	public static void main(String[] args) 
	{
		Vehicle v = new SportsCar();

		if( v instanceof Car )
		{
			// type casting v to car
			Car c = (Car)v;
			System.out.println("Object is of type Car");
		}
		else
		{
			System.out.println("Object is NOT of type Car");
		}
	}
}
