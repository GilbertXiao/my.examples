import java.io.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

class ReplyExample2 {
  public static void main (String args[]) throws Exception
	{
    String host			= "localhost";
    String sendHost = "localhost";
    String username = "abc";
    String password = "abcpassword";
    String from			= "abc@j2ee.com";

    // Create empty properties
    Properties props = System.getProperties();
    props.put("mail.smtp.host", sendHost);

    // Get session
    Session session = Session.getDefaultInstance(props, null);

    // Get the store
    Store store = session.getStore("pop3");
    store.connect(host, username, password);

    // Get folder
    Folder folder = store.getFolder("INBOX");
    folder.open(Folder.READ_ONLY);

    BufferedReader reader = new BufferedReader (
      new InputStreamReader(System.in));

    // Get directory
    Message message[] = folder.getMessages();

	for (int i=0, n=message.length; i<n; i++)
	{
    message[i].writeTo(System.out);

    System.out.println("Do you want to reply to the message? [YES to reply/QUIT to end]");

		String line = reader.readLine();
      
		if ("YES".equalsIgnoreCase(line)) {

        // Create a reply message
       MimeMessage reply = 
				(MimeMessage)message[i].reply(false);

       // Set the from field
     reply.setFrom(new InternetAddress(from));

      // Create the reply content, copying over the original if text
      MimeMessage orig = (MimeMessage)message[i];
      StringBuffer buffer = new StringBuffer("Thanks for writing.\n\n");
      if (orig.isMimeType("text/plain")) {
          String content = (String)orig.getContent();
          StringReader contentReader = new StringReader(content);
          BufferedReader br = new BufferedReader(contentReader);
          String contentLine;
          while ((contentLine = br.readLine()) != null) {
            buffer.append(">>");
            buffer.append(contentLine);
            buffer.append("\r\n");
          }
        }

        // Set the content
        reply.setText(buffer.toString());

        // Send the message
        Transport.send(reply);

				System.out.println("Reply Sent");

      } else if ("QUIT".equals(line)) {
        break;
      }
    }

    // Close connection 
    folder.close(false);
    store.close();
  }
}
