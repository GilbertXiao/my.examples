import java.util.*;
import javax.mail.*;				  // Session,Transport
import javax.mail.internet.*; // MimeMessage

public class MailExample 
{
	public static void main (String args[]) throws Exception 
	{
    Properties props = System.getProperties();

    props.put("mail.smtp.host", "localhost");
    //props.put("mail.debug", "true");

    Session session = 
			Session.getInstance(props, null);

		MimeMessage message = 
					new MimeMessage(session);

		message.setFrom
			(new InternetAddress("xyz@j2ee.com"));

		message.addRecipient
		( Message.RecipientType.TO,
		  new InternetAddress("abc@j2ee.com")
		);

	  message.setSubject("Hello JavaMail");	

		String body = 
			"This is a test mail through Java.";

		message.setContent(body,"text/plain");

		Transport.send(message);

		System.out.println("Mail Send Sucessfully...");
  }
}