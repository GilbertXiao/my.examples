import java.io.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class GetMessageExample
{
  public static void main(String args[]) throws Exception 
	{
    String host = "localhost";
    String username = "abc";
    String password = "abcpassword";

    Properties props = new Properties();

		Session session = 
			Session.getDefaultInstance(props, null);

    Store store = session.getStore("pop3");
    store.connect(host, username, password);

    Folder folder = store.getFolder("INBOX");

    folder.open(Folder.READ_WRITE);

    BufferedReader reader = new BufferedReader 
					(new InputStreamReader(System.in));

   Message message[] = folder.getMessages();

  for (int i=0, n=message.length; i<n; i++) 
	{
		 System.out.println
			 (i + ": " + message[i].getFrom()[0] 
         + "\t" + message[i].getSubject());

      System.out.println
		  ("Do you want to read message? [YES to read/QUIT to end]");
 
      String line = reader.readLine();

    if (line.equalsIgnoreCase("yes"))
	  {
			if(message[i].isMimeType("text/*"))
			{
			  System.out.println(message[i].getContent());
			}

			else if(message[i].isMimeType("multipart/*"))
			{
				Multipart parts = 
					(Multipart)message[i].getContent();

				int count = parts.getCount();

				for(int j=0; j<count; j++)
				{
					BodyPart part = parts.getBodyPart(j);

					System.out.println("Part NO : " + j);

					if(part.isMimeType("text/*"))
					{
						System.out.println(part.getContent());
					}		
					else
					{
						System.out.println("Part is not a text"); 
					}		
				}
			}
  		message[i].setFlag
							( Flags.Flag.DELETED, true );
	  } 

	  else if (line.equalsIgnoreCase("QUIT")) 
	  {
        continue;
      }
    }

    // Close connection 
    folder.close(true);
    store.close();
  }
}
