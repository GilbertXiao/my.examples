import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class HtmlImageExample2
{
  public static void main (String args[]) throws Exception {

		// Get system properties
    Properties props = System.getProperties();

    // Setup mail server
    props.put("mail.smtp.host", "localhost");

    // Get session
    Session session = 
			Session.getInstance(props, null);

    // Create the message
    Message message = new MimeMessage(session);

   // Fill its headers
   message.setSubject("Embedded Image");
   message.setFrom
		 (new InternetAddress("xyz@j2ee.com"));

   message.addRecipient
		 (Message.RecipientType.TO, 
		  new InternetAddress("abc@j2ee.com"));

	BodyPart part1 = new MimeBodyPart();

	String htmlText = 
		"<H1><i>Hello Again</i></H1>" + 
		"<img src='cid:myimage'></img>" + 
		"<br><h1>After the image</h1>"	;

	part1.setContent(htmlText, "text/html");

	BodyPart part2 = new MimeBodyPart();
	DataSource fds = new FileDataSource(args[0]);
	part2.setDataHandler(new DataHandler(fds));
	part2.setHeader("Content-ID","myimage");

 // Create a related multi-part to combine the parts

 MimeMultipart multipart = 
	 new MimeMultipart("related");

 multipart.addBodyPart(part1);
 multipart.addBodyPart(part2);

   // Associate multi-part with message
   message.setContent(multipart);

    // Send message
    Transport.send(message);
  }
}