import java.util.*;
import javax.mail.*;				  // Session,Transport
import javax.mail.internet.*; // MimeMessage

public class MailExample2 
{
	public static void main (String args[]) throws Exception 
	{
    Properties props = System.getProperties();

    props.put("mail.smtp.host", "localhost");
    //props.put("mail.debug", "true");

    Session session = 
			Session.getInstance(props, null);

		MimeMessage message = 
					new MimeMessage(session);

		message.setFrom
			(new InternetAddress("xyz@j2ee.com"));

		message.addRecipient
		( Message.RecipientType.TO,
		  new InternetAddress("abc@j2ee.com")
		);

	  message.setSubject("Multipart Demo");	

		String body1 = "This is First Part.";
		String body2 = "This is Second Part.";

		BodyPart part1 = new MimeBodyPart();
		part1.setContent(body1, "text/plain");

		BodyPart part2 = new MimeBodyPart();
		part2.setContent(body2, "text/plain");

		Multipart myMultipart = new MimeMultipart();
		myMultipart.addBodyPart( part1 );
		myMultipart.addBodyPart( part2 );
		
		message.setContent( myMultipart );
		Transport.send(message);

		System.out.println("Mail Send Sucessfully...");
  }
}