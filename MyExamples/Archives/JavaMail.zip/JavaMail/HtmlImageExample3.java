import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class HtmlImageExample3
{
  public static void main (String args[]) throws Exception {

		// Get system properties
    Properties props = System.getProperties();

    // Setup mail server
    props.put("mail.smtp.host", "localhost");

    // Get session
    Session session = 
			Session.getInstance(props, null);

    // Create the message
    Message message = new MimeMessage(session);

   // Fill its headers
   message.setSubject("Embedded Image");
   message.setFrom
		 (new InternetAddress("xyz@j2ee.com"));

   message.addRecipient
		 (Message.RecipientType.TO, 
		  new InternetAddress("abc@j2ee.com"));

 // Create your new message part

String htmlText = 
	"<html>" + 
		"<body><h1>" + 
				"This is line one.<br>" + 
				"This is line two.<br>" + 
				"<img src = 'cid:myimage'></img>" + 
				"<br>This line is after Image." + 
		"</h1></body>" + 
	"</html>";

// Set the content of the body part
BodyPart part1 = new MimeBodyPart();
part1.setContent( htmlText, "text/html" );

DataSource fds = new FileDataSource(args[0]);
BodyPart part2 = new MimeBodyPart();
part2.setDataHandler(new DataHandler(fds));
part2.setHeader("Content-ID","myimage");

// Create a related multi-part to combine the parts
Multipart multipart = new MimeMultipart("related");
multipart.addBodyPart(part1);
multipart.addBodyPart(part2);

	message.setContent(multipart);
	Transport.send(message);

  }
}