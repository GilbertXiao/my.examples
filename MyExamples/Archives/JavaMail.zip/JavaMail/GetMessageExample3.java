import java.io.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

class MyTextHandler
{
	MyTextHandler(Part part)
	{
		try	{
			System.out.println(part.getContent());
		}
		catch(Exception e)
		{}
	}
}

class MyMultipartHandler
{
	Multipart parts;

	MyMultipartHandler(Multipart parts)
	{
		this.parts = parts;
	}

	void handleParts() throws Exception
	{
		int count = parts.getCount();

		for(int i=0; i<count; i++)
		{
			BodyPart part = parts.getBodyPart(i);
			
			if(part.isMimeType("text/*"))
			{
				new MyTextHandler(part);
			}
			else if(part.isMimeType("multipart/*"))
			{
				MyMultipartHandler handler = 
					new MyMultipartHandler((Multipart)part.getContent());

				handler.handleParts();
			}
			else
			{
				System.out.println
					("Part is type "+ part.getContentType());
			}
		}
	}
}


public class GetMessageExample3
{
  public static void main(String args[]) throws Exception 
	{
    String host = "localhost";
    String username = "abc";
    String password = "abcpassword";

    Properties props = new Properties();

		Session session = 
			Session.getDefaultInstance(props, null);

    Store store = session.getStore("pop3");
    store.connect(host, username, password);

    Folder folder = store.getFolder("INBOX");

    folder.open(Folder.READ_WRITE);

    BufferedReader reader = new BufferedReader 
						(new InputStreamReader(System.in));

  Message message[] = folder.getMessages();

  for (int i=0, n=message.length; i<n; i++) 
	{
		 System.out.println
		 ("From : " + message[i].getFrom()[0] + 
			"\nSubject : " + message[i].getSubject());

		System.out.println
		("Do you want to read message? [YES to read/QUIT to end]");
 
    String line = reader.readLine();

    if (line.equalsIgnoreCase("yes"))
	  {
			if(message[i].isMimeType("text/*"))
			{
			  new MyTextHandler(message[i]);
			}

			else if(message[i].isMimeType("multipart/*"))
			{
				Multipart parts = 
					(Multipart)message[i].getContent();

				new MyMultipartHandler(parts).handleParts();
			}
  		message[i].setFlag(Flags.Flag.DELETED,true);
	  } 

	  else if (line.equalsIgnoreCase("QUIT")) 
	  {
        continue;
    }
   }

    // Close connection 
    folder.close(true);
    store.close();
  }
}