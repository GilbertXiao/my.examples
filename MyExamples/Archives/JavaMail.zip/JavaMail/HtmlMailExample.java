
import java.util.*;
import javax.mail.*;				  // Session,Transport
import javax.mail.internet.*; // MimeMessage

public class HtmlMailExample 
{
	public static void main (String args[]) 
	throws Exception 
	{
    Properties props = System.getProperties();

    props.put("mail.smtp.host", "localhost");

    Session session = 
				Session.getInstance(props, null);

	MimeMessage message = new MimeMessage(session);

  message.setFrom
		(new InternetAddress("xyz@j2ee.com"));

	message.addRecipient
	 (Message.RecipientType.TO,
	  new InternetAddress("abc@j2ee.com"));

  message.setSubject("Hello JavaMail");

String htmlText = 
	"<html><body><h1><font color='red'>Hello</font></h1></body></html>";

	message.setContent(htmlText,"text/html");

	Transport.send(message);

	System.out.println("Mail Send Sucessfully...");

  }
}