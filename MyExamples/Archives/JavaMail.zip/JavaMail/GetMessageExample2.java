import java.io.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class GetMessageExample2 
{
  public static void main (String args[]) throws Exception 
  {
    String host = "localhost";
    String username = "abc";
    String password = "abcpass";

    Properties props = System.getProperties();

    Session session = 
			Session.getDefaultInstance(props, null);

    Store store = session.getStore("pop3");
    store.connect(host, username, password);

//    Folder folder = store.getFolder("INBOX");

		Folder folder = 
		   store.getDefaultFolder().getFolder("INBOX");

    folder.open(Folder.READ_WRITE);

    BufferedReader reader = new BufferedReader
								(new InputStreamReader(System.in));

    // Get directory
    Message message[] = folder.getMessages();

  for (int i=0, n=message.length; i<n; i++) 
	{
     System.out.println(i + ": " + message[i].getFrom()[0] 
        + "\t" + message[i].getSubject());

		message[i].
		
		
		message[i].setFlag(Flags.Flag.DELETED,true);

  }

    // Close connection 
    folder.close(true);
    store.close();
  }
}
