import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class ProviderList
{
	public static void main (String args[]) 
	throws Exception 
	{

	// Get system properties
    Properties props = System.getProperties();

    // Get session
    Session session = 
		Session.getInstance(props, null);

	Provider pro[] = session.getProviders();

	for(int i=0;i<pro.length;i++)
	{
		System.out.println(pro[i]);	
	}

	}
}