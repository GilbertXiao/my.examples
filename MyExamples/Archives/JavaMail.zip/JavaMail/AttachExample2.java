
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class AttachExample2 
{
  public static void main (String args[]) 
  throws Exception 
  {
    Properties props = System.getProperties();
    props.put("mail.smtp.host", "localhost");

    Session session = 
						Session.getInstance(props, null);

    Message message = new MimeMessage(session);

		message.setFrom
			(new InternetAddress("xyz@deccansoft.com"));
    
		message.addRecipient
		(Message.RecipientType.TO,
		 new InternetAddress("abc@deccansoft.com"));

  message.setSubject("Mail with Attachment");

BodyPart part1 = new MimeBodyPart();
part1.setText("This is the text Part");

//part1.setContent("<font color ='red'>Here's the text</font>","text/html");


  BodyPart part2	  = new MimeBodyPart();

	DataSource source = new FileDataSource(args[0]);
	DataHandler d			= new DataHandler(source);
  part2.setDataHandler(d);
  part2.setFileName(args[0]);

	Multipart multipart = new MimeMultipart();

	multipart.addBodyPart(part1);
	multipart.addBodyPart(part2);

    // Put parts in message
    message.setContent(multipart);

    // Send the message
    Transport.send(message);
	
		System.out.println("Mail Send Sucessfully...");

  }
}