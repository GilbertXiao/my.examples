@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.com/schemas/HelloWorld")
package com.example.schemas.helloworld;
