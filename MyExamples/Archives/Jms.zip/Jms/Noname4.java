
Message = session.createMessage()

TextMessage = session.createTextMessage()

ObjectMessage = session.createObjectMessage()

MapMessage = session.createMapMessage()

BytesMessage = session.createBytesMessage()

StreamMessage = session.createStreamMessage()





