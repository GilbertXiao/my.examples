@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.com/schemas/Banking")
package com.example.schemas.banking;
