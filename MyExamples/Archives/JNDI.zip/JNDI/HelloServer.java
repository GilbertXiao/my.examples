
import demo.*;
import java.rmi.*;
import java.rmi.server.*;

class HelloServer
{
	public static void main(String[] args) 
	throws Exception
	{
		HelloImpl r = new HelloImpl();
		System.out.println("Object Created");

		UnicastRemoteObject.exportObject( r );
		System.out.println("Object Exported");

		Naming.rebind("hello", r);
		System.out.println("Object Binded");
	}
}