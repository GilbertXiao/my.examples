
import demo.*;
import java.rmi.*;

class HelloClient
{
	public static void main(String[] args) 
	throws Exception
	{
		Remote ref = 
			Naming.lookup("rmi://localhost:1099/hello");

		Hello helloRef = (Hello)ref;
		String result = helloRef.sayHello(args[0]);
		System.out.println(result);
	}
}