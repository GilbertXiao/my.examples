package demo;

import java.rmi.*;

public class HelloImpl implements Hello
{
	public String sayHello(String s)
	{
		return "Hello " + s;
	}
}