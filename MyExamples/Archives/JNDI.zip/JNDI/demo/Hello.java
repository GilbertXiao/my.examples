
package demo;


public interface Hello extends java.rmi.Remote
{
	public String sayHello(String s) 
						throws java.rmi.RemoteException;
}