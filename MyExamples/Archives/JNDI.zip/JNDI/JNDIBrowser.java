
import javax.naming.*;

public class JNDIBrowser
{
	public static void main(String args[]) throws Exception
	{	
		Context ctx = new InitialContext();
		NamingEnumeration enum = ctx.list("");

		while( enum.hasMore() )
		{
			NameClassPair entry = 
				(NameClassPair)enum.next();

			System.out.println( entry.getName() );
		}
	} 
}