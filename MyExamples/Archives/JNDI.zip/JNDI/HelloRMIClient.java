
import demo.*;
import java.rmi.*;

class HelloRMIClient
{
	public static void main(String[] args) 
	throws Exception
	{
		Remote r = Naming.lookup("hello");
		Hello  h  = (Hello)r;
		String result = h.sayHello(args[0]);
		System.out.println(result);
	}
}