import demo.*;
import java.io.*;
import java.rmi.*;
import java.util.*;

import javax.naming.*;

class HelloJNDIClient
{
	public static void main(String[] args) throws Exception
	{
		Context ctx = new InitialContext();

		Object ref  = ctx.lookup("hello");
		Hello helloRef = (Hello)ref;
		String result = helloRef.sayHello(args[0]);
		System.out.println(result);
	}
}