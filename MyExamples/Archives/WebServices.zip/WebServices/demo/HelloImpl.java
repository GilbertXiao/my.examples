package demo;

public class HelloImpl
{
	public String sayHello(String s) 
	{
		return "Hello From WebService " + s;
	}
}