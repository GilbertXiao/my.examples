// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/moviedemo/DemoServlet.java,v 1.7 2003/08/13 04:04:23 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */

package daoexamples.moviedemo;

import javax.servlet.http.*;
import javax.transaction.*;
import java.io.*;
import java.util.*;
import daoexamples.exception.*;
import daoexamples.movie.*;
import org.apache.commons.logging.*;

/**
 * 
 * @author Sean C. Sullivan
 * 
 */
public class DemoServlet extends HttpServlet
{
	static final private Log log = LogFactory.getLog(DemoServlet.class);
	
	public void setupDemo()
	{
		
		Exception caught = null;
	
		MovieDAO dao = null;
		
		UserTransaction utx = null;
		
		try
		{
			MovieUtil.setupMovieTable();

			dao = MovieDAOFactory.getMovieDAO_JTA();
			
			utx = MovieUtil.getUserTransaction();		
		
			log.info("UserTransaction status: "
					+ utx.getStatus());
	
			utx.begin();
			
			log.info("UserTransaction status: "
					+ utx.getStatus());
	
			dao.createMovie("R", "1999", "Game Day");
			dao.createMovie("G", "1999", "Tarzan");
			dao.createMovie("R", "2005", "Blair Witch Project Reloaded");
			dao.createMovie("PG-13", "2005", "Raiders of the Lost Ark Reloaded");
			dao.createMovie("R", "2005", "Bridget Jones Diary Reloaded");
			
			utx.commit();
			
			log.info("UserTransaction status: "
					+ utx.getStatus());
		}
		catch (Exception ex)
		{
			caught = ex;
			log.error(ex);
			if (utx != null)
			{
				try
				{
					utx.rollback();
				}
				catch (javax.transaction.SystemException ex2)
				{
					log.error(ex2);
				}
			}
		}
		finally
		{
			dao.close();
			if (caught != null)
			{
				throw new DAORuntimeException(caught); 
			}
		}
		
	}
	
	/**
	 *  
	 * 
	 * @throws daoexamples.exception.DAORuntimeException
	 *
	 */
	public void executeMovieDAO_JTA()
	{
		Exception caught = null;
		
		//
		//
		// This DAO expects the caller  
		// to demarcate the transaction using JTA
		//
		//
		MovieDAO dao = MovieDAOFactory.getMovieDAO_JTA();

		MessagePublisher publisher = null;

		UserTransaction utx = MovieUtil.getUserTransaction();
				
		try 
		{
			Movie matrix;
			Movie topgun;
			Movie linux;
			Movie batman;
	
			//
			// Execute the first transaction
			//
	
			utx.begin();
			
			matrix = dao.createMovie("R", "2003", "Matrix Reloaded");
			topgun = dao.createMovie("R", "2004", "Top Gun Reloaded");
			linux = dao.createMovie("R", "2004", "Linux Reloaded");
			
			utx.commit();
			
			
			//
			// Execute a second transaction. 
			// 
			// This transaction accesses two resources:
			//   1) a JMS Topic
			//   2) a JDBC DataSource
			//
			
			utx.begin();
	
			batman = dao.createMovie("R", "2004", "Batman Reloaded");
			
			publisher = new MessagePublisher();
			
			publisher.publishTextMessage("Hello world");
			
			dao.updateMovie(topgun.getId(),
							"PG-13",
							topgun.getReleaseYear(),
							topgun.getTitle());
							
			dao.deleteMovie(linux.getId());
			
			utx.commit();
			
		} 
		catch (Exception ex) 
		{
			log.error(ex);
			caught = ex;
			if (utx != null)
			{			
				try 
				{
					utx.rollback();
				} 
				catch (SystemException sysex) 
				{
					log.error(sysex); 
				}
			}
		}
		finally
		{
			if (dao != null)
			{
				dao.close();
				dao = null;
			}
			if (publisher != null)
			{
				publisher.close();
				publisher = null;
			}
			if (caught != null)
			{
				throw new DAORuntimeException(caught);
			}
		}
	}
	
	public void executeMovieDAO()
	{
		MovieDAO dao;

		//
		//
		// This DAO uses JDBC transactions.
		// 
		// The DAO controls transaction demarcation.
		//
		//
		dao = MovieDAOFactory.getMovieDAO();

		Movie spykids = null;
		spykids = dao.createMovie(
					"PG", "2003", "Spy Kids 3-D");
		
		Movie americanwedding = null;
		americanwedding = dao.createMovie(
					"R", "2003", "American Wedding");
		
		Movie johnnyenglish = null;
		johnnyenglish = dao.createMovie(
					"PG", "2003", "Johnny English");

		String strMovieId = spykids.getId();
				
		try
		{
			Movie foundMovie = null;
			
			foundMovie = dao.findMovieById(strMovieId);

			log.info(foundMovie);
		}
		catch (MovieNotFoundException ex)
		{
			log.info("Movie id " + strMovieId + " not found");
		}
		
		
		Collection moviesFrom1999 = dao.findMoviesByYear("1999");
		
		if (moviesFrom1999.size() > 0)
		{
			StringBuffer msg = new StringBuffer();
			msg.append("Movies from 1999:\n");
			
			Iterator iter = moviesFrom1999.iterator();
		
			while (iter.hasNext())
			{
				Movie m = (Movie) iter.next();
				msg.append("\t");
				msg.append(m);
				msg.append("\n");
			}
			
			log.info(msg.toString());
		}
		else
		{
			log.info("There are no movies from 1999");
		}
		
	}
	
	public void doGet(final HttpServletRequest req, 
					  final HttpServletResponse resp)
					  throws java.io.IOException
	{
		String strMsg = "";
		
		try
		{
			setupDemo();

			executeMovieDAO();
			
			executeMovieDAO_JTA();		
			
			strMsg = "Success!";
		}
		catch (Exception ex)
		{
			java.io.StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			ex.printStackTrace(pw);
			strMsg = sw.getBuffer().toString();
		}

		String strHTML = buildResponsePage(strMsg);
		
		resp.setContentType("text/html");
		resp.setContentLength(strHTML.length());
		resp.setHeader("Cache-Control", "no-cache");
		
		PrintWriter writer = resp.getWriter();
		writer.println(strHTML);
		writer.flush();
	}
	
	private String buildResponsePage(String strMsg)
	{
		StringBuffer sbHTML = new StringBuffer();
		
		sbHTML.append("<html>");
		sbHTML.append("<body>");
		sbHTML.append(new java.util.Date());
		sbHTML.append("<br>");
		sbHTML.append("<pre>");
		sbHTML.append(strMsg); 
		sbHTML.append("</pre>");
		sbHTML.append("</body>");
		sbHTML.append("</html>");
		
		return sbHTML.toString(); 

	}
}
