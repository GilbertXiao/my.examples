// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/moviedemo/MessagePublisher.java,v 1.3 2003/08/12 04:41:02 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */
 
package daoexamples.moviedemo;

import daoexamples.exception.*;
import javax.jms.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import org.apache.commons.logging.*;

/**
 *
 * publishes messages to a JMS Topic
 *
 * You can learn more about the Java Message Service at  
 * <a href="http://java.sun.com/products/jms/">http://java.sun.com/products/jms/</a>
 * 
 * This class assumes that transactions are externally 
 * demaracated using JTA
 *
 * Instances of this class are not thread-safe.
 *    
 * @author Sean C. Sullivan
 * 
 */
class MessagePublisher
{
	static private final Log log = LogFactory.getLog(MessagePublisher.class);
	static private final String TOPIC_CF_JNDI_NAME = "java:comp/env/jms/MovieTCF";
	static private final String TOPIC_JNDI_NAME = "java:comp/env/jms/MovieTopic";
	
	private TopicConnection tconn;
	private TopicSession tsess;
	private TopicPublisher publisher;
	private Topic top;
	private boolean bIsClosed = false;

	/**
	 *  
	 * Before calling this constructor, you must have 
	 * a JTA UserTransaction
	 *
	 * @throws daoexamples.exception.DAORuntimeException
	 * 
	 */
	public MessagePublisher()
	{
		try
		{
			tconn = getTopicConnection();
			tsess = tconn.createTopicSession(
								true /* true == session is transacted */, 
								TopicSession.AUTO_ACKNOWLEDGE);
			top = getTopic();
			publisher = tsess.createPublisher(top);
		}
		catch (JMSException ex)
		{
			throw new DAORuntimeException(ex);
		}
			
	}

   /**
    * 	
	* @throws daoexamples.exception.DAORuntimeException
	* 
	*/
	static private InitialContext getInitialContext()
	{
	
		InitialContext ctx = null;
		
		try
		{
			ctx = new InitialContext();
		}
		catch (NamingException ex)
		{
			throw new DAORuntimeException(ex);
		}
	
		return ctx;
	
	}
	
	/**
	 * 	
	 * @throws daoexamples.exception.DAORuntimeException
	 * 
	 */
	static private Topic getTopic()
	{
		InitialContext ctx = getInitialContext();
	
		Topic result = null;
	
		Object topicObject = null;
	
		try
		{
			topicObject = ctx.lookup(TOPIC_JNDI_NAME);
			result = (Topic) PortableRemoteObject.narrow(
								topicObject,
								Topic.class);
		}
		catch (NamingException ex)
		{
			throw new DAORuntimeException(ex);
		}
	
		return result;
	}
	
	/**
	 * 	
	 * @throws daoexamples.exception.DAORuntimeException
	 * 
	 */
	static private TopicConnection getTopicConnection()
	{
		TopicConnectionFactory tcf = getTopicConnectionFactory();
	
		TopicConnection tconn = null;
	
		try
		{
			tconn = tcf.createTopicConnection();
		}
		catch (JMSException ex)
		{
			throw new DAORuntimeException(ex);
		}
	
		return tconn;
	
	}
	
	/**
	 * 	
	 * @throws daoexamples.exception.DAORuntimeException
	 * 
	 */
	static private TopicConnectionFactory getTopicConnectionFactory()
	{
		InitialContext ctx = getInitialContext();
	
		TopicConnectionFactory tcf = null;
	
		Object tcfObject = null;
	
		try
		{
			tcfObject = ctx.lookup(TOPIC_CF_JNDI_NAME);
			tcf = (TopicConnectionFactory) PortableRemoteObject.narrow(
							tcfObject,
							TopicConnectionFactory.class);
		}
		catch (NamingException ex)
		{
			throw new DAORuntimeException(ex);
		}
			
		return tcf;
	}
	
	
	/**
	 *  
	 * @param strText must be non-null
	 *
	 * @throws daoexamples.exception.DAORuntimeException
	 *  
	 */
	public void publishTextMessage(final String strText)
	{
		if (isClosed())
		{
			throw new java.lang.IllegalStateException("MessagePublisher is closed");
		}
		
		if (null == strText)
		{
			throw new NullPointerException("strText parameter");
		}
		
		try
		{
			TextMessage textMsg = tsess.createTextMessage(strText);
			publisher.publish(textMsg);
		}
		catch (JMSException ex)
		{
			throw new DAORuntimeException(ex);
		}
		
	}  

	/**
	 *  
	 * @return true if this object is closed
	 * 
	 * @see #close()
	 * 
	 */
	public boolean isClosed()
	{
		return bIsClosed;
	}
		
	/**
	 * 
	 *  @see #isClosed()
	 *
	 */
	public void close()
	{
		log.info("close() called");
		
		if ( ! isClosed() )
		{
			bIsClosed = true;
			
			top = null;
			
			if (publisher != null)
			{
				try
				{
					publisher.close();
				}
				catch (JMSException ex)
				{
					log.error("exception while closing a TopicPublisher",
							ex); 
				}
				finally
				{
					publisher = null;
				}
			}
			
			if (tsess != null)
			{
				try
				{
					tsess.close();
				}
				catch (JMSException ex)
				{
					log.error("exception while closing a TopicSession",
							ex); 
				}
				finally
				{
					tsess = null;
				}
			}
			
			if (tconn != null)
			{
				try
				{
					tconn.close();
				}
				catch (JMSException ex)
				{
					log.error("exception while closing a TopicConnection",
							ex); 
				}
				finally
				{
					tconn = null;
				}
			}
		}
		
	}
}
