// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/exception/DAORuntimeException.java,v 1.2 2003/08/04 04:03:28 sullis Exp $ 

/*
 * 
 *
 * 
 * 
 */
package daoexamples.exception;

import org.apache.commons.lang.exception.*;

/**
 * 
 * 
 * Because we want this class to be compatible with
 * J2SE 1.3.x and IBM Websphere 5.x, we can't use
 * the "chained exception" capabilities from J2SE 1.4
 *
 * Due to this requirement, this class will extend   
 * NestableRuntimeException, provided by the 
 * Jakarta Commons Lang library.
 *  
 * @author Sean C. Sullivan
 *
 */
public class DAORuntimeException 
	extends NestableRuntimeException
{
	public DAORuntimeException(final Throwable cause)
	{
		super(cause);	
	}
	
	public DAORuntimeException(
				final String msg,
				final Throwable cause)
	{
		super(msg, cause);	
	}
	
	public DAORuntimeException(
				final String msg)
	{
		super(msg);	
	}
	
}
