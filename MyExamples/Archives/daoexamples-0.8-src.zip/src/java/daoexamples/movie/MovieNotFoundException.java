// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieNotFoundException.java,v 1.2 2003/08/06 04:33:59 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */
 
package daoexamples.movie;

import org.apache.commons.lang.exception.*;

/**
 * 
 * 
 * @author Sean C. Sullivan
 *
 * 
 * 
 */
public class MovieNotFoundException extends NestableException
{
	public MovieNotFoundException(String msg)
	{
		super(msg);
	}
	
	public MovieNotFoundException(Throwable t)
	{
		super(t);
	}

	public MovieNotFoundException(String msg, Throwable t)
	{
		super(msg, t);
	}

}
