// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieDAOFactory.java,v 1.6 2003/08/13 04:16:18 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */
 
package daoexamples.movie;

/**
 * <p>
 * Normally, a DAO factory class contains 
 * only one public "getFooDAO" method. This class provides 
 * two "get" methods because we want this factory to expose 
 * both of the {@link MovieDAO} implementations. 
 * </p>
 * 
 * @author Sean C. Sullivan
 *
 */
public final class MovieDAOFactory
{
	private MovieDAOFactory()
	{
		// this constructor is intentionally private
	}

	/**
	 * 
	 * 
	 * @return a non-null value. The DAO returned by this
	 *            method uses JDBC transactions. The DAO 
	 *            demaractes transactions internally.
	 *  
	 * @see #getMovieDAO_JTA()
	 * 
	 * 
	 */
	public static MovieDAO getMovieDAO()
	{
		return new MovieDAOImpl();
	}

	/**
	 * 
	 * @return a non-null value. The DAO returned by this
	 *         method assumes that the caller is using JTA 
	 *         transactions. Transactions are demarcated external 
	 *         to the DAO.
	 *  
	 * @see #getMovieDAO()
	 * 
	 */
	public static MovieDAO getMovieDAO_JTA()
	{
		return new MovieDAOImplJTA();
	}
	
}
