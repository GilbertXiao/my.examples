// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieDAOImpl.java,v 1.5 2003/08/25 03:30:12 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */

package daoexamples.movie;

import java.sql.*;
import java.util.*;
import daoexamples.exception.*;

import org.apache.commons.logging.*;

/**
 *
 * <p>
 * This <b>Data Access Object</b> demarcates transactions
 * internally.  The caller cannot demarcate transactions.
 * Transactions are demarcated using the JDBC API.
 * </p>
 * <p>
 * Instances of this class are not thread-safe. 
 * </p>      
 *
 * @see MovieDAOImplJTA
 *  
 * @author Sean C. Sullivan
 *
 * 
 */
class MovieDAOImpl implements MovieDAO
{
	static final private Log log = LogFactory.getLog(MovieDAOImpl.class);
	
	private boolean bIsClosed = false;
	
	/**
	 * 
	 * 
	 *    
	 * 
	 */
	public MovieDAOImpl()
	{
		bIsClosed = false;
	}
	
	public Movie findMovieById(final String id)
		throws MovieNotFoundException
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}

		Connection conn = MovieUtil.getNonXADBConnection();
		
		Movie result = null;
		ResultSet rs = null;
		PreparedStatement stmtSelect = null;
		
		try
		{
			StringBuffer sbSelect = new StringBuffer();
			
			sbSelect.append("SELECT movie_id, rating, year, title FROM ");
			sbSelect.append(MovieConstants.MOVIE_TABLE_NAME);
			sbSelect.append(" WHERE movie_id = ?");
			
			stmtSelect = conn.prepareStatement(sbSelect.toString());
			
			stmtSelect.setString(1, id);
			
			rs = stmtSelect.executeQuery();
			Collection c = MovieUtil.makeMovieObjectsFromResultSet(rs);
			
			if (c.size() != 1)
			{
				throw new MovieNotFoundException("id = " + id);
			}
			
			Iterator iter = c.iterator();
			
			result = (Movie) iter.next();      
		}
		catch (SQLException ex)
		{
			log.error(ex);
			throw new DAORuntimeException(ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtSelect);
			MovieUtil.closeResultSet(rs);
			MovieUtil.closeJDBCConnection(conn);
		}
		
		return result;
	}
	
	public java.util.Collection findMoviesByYear(final String year)
	{
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		
		Connection conn = MovieUtil.getNonXADBConnection();
		
		Collection result = null;
		
		ResultSet rs = null;
		PreparedStatement stmtSelect = null;
		
		try
		{
			StringBuffer sbSelect = new StringBuffer();
			
			sbSelect.append("SELECT movie_id, rating, year, title FROM ");
			sbSelect.append(MovieConstants.MOVIE_TABLE_NAME);
			sbSelect.append(" WHERE year = ?");
			
			stmtSelect = conn.prepareStatement(sbSelect.toString());
			
			stmtSelect.setString(1, year);
			
			rs = stmtSelect.executeQuery();
			
			result = MovieUtil.makeMovieObjectsFromResultSet(rs);

		}
		catch (SQLException ex)
		{
			log.error(ex);
			throw new DAORuntimeException(ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtSelect);
			MovieUtil.closeResultSet(rs);
			MovieUtil.closeJDBCConnection(conn);
		}
		
		return result;
	}
	
	public void deleteMovie(final String id)
		throws MovieNotFoundException
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}
		
		Connection conn = MovieUtil.getNonXADBConnection();
		
		PreparedStatement stmtDelete = null;
		
		try
		{
			StringBuffer sbDelete = new StringBuffer();
			
			sbDelete.append("DELETE FROM ");
			sbDelete.append(MovieConstants.MOVIE_TABLE_NAME);
			sbDelete.append(" WHERE movie_id = ?");
			
			stmtDelete = conn.prepareStatement(sbDelete.toString());
			
			stmtDelete.setString(1, id);
			
			int rows = stmtDelete.executeUpdate();
			
			if (rows != 1)
			{
				throw new SQLException(
					"executeUpdate return value: "
					+ rows);
			}
			
		}
		catch (SQLException ex)
		{
			log.error(ex);
			throw new DAORuntimeException(ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtDelete);
			MovieUtil.closeJDBCConnection(conn);
		}
	}
	
	public Movie createMovie(
					final String rating, 
					final String year, 
					final String title)
	{
		if (rating == null)
		{
			throw new NullPointerException("rating parameter");
		}
		
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		if (title == null)
		{
			throw new NullPointerException("title parameter");
		}
		
		Movie result = null;
		PreparedStatement stmtInsert = null;

		Connection conn = MovieUtil.getNonXADBConnection();

		try
		{
			String movie_id = MovieUtil.getUniqueMovieId(conn);
			
			StringBuffer sbInsert = new StringBuffer();
			
			sbInsert.append("INSERT INTO ");
			sbInsert.append(MovieConstants.MOVIE_TABLE_NAME);
			sbInsert.append(" ( movie_id, rating, year, title ) ");
			sbInsert.append(" VALUES (");
			sbInsert.append(movie_id);
			sbInsert.append(", ?, ?, ?) ");
			
			stmtInsert = conn.prepareStatement(sbInsert.toString());
			
			stmtInsert.setString(1, rating);
			stmtInsert.setString(2, year);
			stmtInsert.setString(3, title);
			
			log.info("About to execute INSERT: values "
				+ rating
				+ ", "
				+ year
				+ ", "
				+ title);
				
			int rows = stmtInsert.executeUpdate();

			if (rows != 1)
			{
				throw new SQLException(
					"executeUpdate return value: "
					+ rows);
			}
			
			result = new MovieImpl(movie_id,
							rating,
							year,
							title);
			
		}
		catch (SQLException ex)
		{
			log.error(ex);
			throw new DAORuntimeException(ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtInsert);
			MovieUtil.closeJDBCConnection(conn);
		}
		return result;
	}

	public void updateMovie(
				final String id, 
				final String rating, 
				final String year, 
				final String title) throws MovieNotFoundException
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}
		
		if (rating == null)
		{
			throw new NullPointerException("rating parameter");
		}
		
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		if (title == null)
		{
			throw new NullPointerException("title parameter");
		}

		Connection conn = MovieUtil.getNonXADBConnection();
		
		PreparedStatement stmtUpdate = null;
		
		try
		{
			StringBuffer sbUpdate = new StringBuffer();
			
			sbUpdate.append("UPDATE ");
			sbUpdate.append(MovieConstants.MOVIE_TABLE_NAME);
			sbUpdate.append(" SET ");
			sbUpdate.append(" rating = ?, ");
			sbUpdate.append(" year = ?, ");
			sbUpdate.append(" title = ? ");
			sbUpdate.append(" WHERE movie_id = ?");
			
			stmtUpdate = conn.prepareStatement(sbUpdate.toString());
			
			stmtUpdate.setString(1, rating);
			stmtUpdate.setString(2, year);
			stmtUpdate.setString(3, title);
			stmtUpdate.setString(4, id);
			
			int rows = stmtUpdate.executeUpdate();
			
			if (rows != 1)
			{
				throw new SQLException(
					"executeUpdate return value: "
					+ rows);
			}
			
		}
		catch (SQLException ex)
		{
			throw new DAORuntimeException(ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtUpdate);
			MovieUtil.closeJDBCConnection(conn);
		}
	}
	
	public void close()
	{
		log.info("close() called");
		bIsClosed = true;
	}
	
	public boolean isClosed()
	{
		return bIsClosed;
	}
	
}
