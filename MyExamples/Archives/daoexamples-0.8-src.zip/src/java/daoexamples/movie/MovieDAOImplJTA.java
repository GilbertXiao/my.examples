// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieDAOImplJTA.java,v 1.7 2003/08/25 03:30:12 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */

package daoexamples.movie;

import java.sql.*;
import java.util.*;
import daoexamples.exception.*;

import org.apache.commons.logging.*;

/**
 * <p>
 * This class is a <b>Data Access Object</b>.
 * </p>
 * <p>
 * This class is designed for use with the Java Transaction API.
 * </p>
 * <p>
 * This class assumes that the caller is using JTA to demarcate 
 * transactions.
 * </p>
 * <p>
 * You can learn more about JTA at
 * <a href="http://java.sun.com/products/jta/">
 * http://java.sun.com/products/jta/</a> 
 * </p>
 * <p> 
 * Instances of this class are not thread-safe.
 * </p>  
 * 
 * @see MovieDAOImpl
 * 
 * @author Sean C. Sullivan
 *
 * 
 */
class MovieDAOImplJTA implements MovieDAO
{
	static final private Log log = LogFactory.getLog(MovieDAOImplJTA.class);
	
	private java.sql.Connection conn = null;
	private boolean bIsClosed;
	
	/**
	 * 
	 * 
	 *    
	 * 
	 */
	public MovieDAOImplJTA()
	{
		bIsClosed = false;
		conn = MovieUtil.getXADBConnection();
	}
	
	public Movie findMovieById(final String id)
		throws MovieNotFoundException
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}

		Movie result = null;
		ResultSet rs = null;
		PreparedStatement stmtSelect = null;
		
		StringBuffer sbSelect = new StringBuffer();
		
		try
		{
			sbSelect.append("SELECT movie_id, rating, year, title FROM ");
			sbSelect.append(MovieConstants.MOVIE_TABLE_NAME);
			sbSelect.append(" WHERE movie_id = ?");
			
			stmtSelect = conn.prepareStatement(sbSelect.toString());
			
			stmtSelect.setString(1, id);

			rs = stmtSelect.executeQuery();
			Collection c = MovieUtil.makeMovieObjectsFromResultSet(rs);
			
			log.debug("sbSelect = "
							+ sbSelect.toString()
							+ ", id = "
							+ id
							+ ", "
							+ c.size()
							+ " rows found");
							
			if (c.size() != 1)
			{
				throw new MovieNotFoundException("id = " + id);
			}
			
			Iterator iter = c.iterator();
			
			result = (Movie) iter.next();      
		}
		catch (SQLException ex)
		{
			StringBuffer sbMsg = new StringBuffer();
			sbMsg.append("sql = { "); 
			sbMsg.append(String.valueOf(sbSelect)); 
			sbMsg.append(" }, id = '"); 
			sbMsg.append(id); 
			sbMsg.append("'"); 
			throw new DAORuntimeException(
							sbMsg.toString(), 
							ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtSelect);
			MovieUtil.closeResultSet(rs);
		}
		
		return result;
	}
	
	public java.util.Collection findMoviesByYear(final String year)
	{
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		
		Collection result = null;
		
		ResultSet rs = null;
		PreparedStatement stmtSelect = null;
		
		StringBuffer sbSelect = new StringBuffer();
		
		try
		{
			sbSelect.append("SELECT movie_id, rating, year, title FROM ");
			sbSelect.append(MovieConstants.MOVIE_TABLE_NAME);
			sbSelect.append(" WHERE year = ?");
			
			stmtSelect = conn.prepareStatement(sbSelect.toString());
			
			stmtSelect.setString(1, year);
			
			rs = stmtSelect.executeQuery();
			
			result = MovieUtil.makeMovieObjectsFromResultSet(rs);

		}
		catch (SQLException ex)
		{
			StringBuffer sbMsg = new StringBuffer();
			sbMsg.append("sbSelect = ");
			sbMsg.append(String.valueOf(sbSelect));
			sbMsg.append(", year = ");
			sbMsg.append(year);
			throw new DAORuntimeException(
							sbMsg.toString(),
							ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtSelect);
			MovieUtil.closeResultSet(rs);
		}
		
		return result;
	}
	
	public void deleteMovie(final String id)
		throws MovieNotFoundException
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}
		
		PreparedStatement stmtDelete = null;
		
		StringBuffer sbSQLDelete = new StringBuffer();
		
		try
		{
			sbSQLDelete.append("DELETE FROM ");
			sbSQLDelete.append(MovieConstants.MOVIE_TABLE_NAME);
			sbSQLDelete.append(" WHERE movie_id = ?");
			
			stmtDelete = conn.prepareStatement(sbSQLDelete.toString());
			
			stmtDelete.setString(1, id);
			
			int rows = stmtDelete.executeUpdate();
			
			if (rows != 1)
			{
				StringBuffer sbMsg = new StringBuffer();
				sbMsg.append("executeUpdate returned ");
				sbMsg.append(rows);
				sbMsg.append(", id = "); 
				sbMsg.append(id); 
				throw new DAORuntimeException(
								sbMsg.toString());
			}
			
		}
		catch (SQLException ex)
		{
			StringBuffer sbMsg = new StringBuffer();
			sbMsg.append("sql = { "); 
			sbMsg.append(String.valueOf(sbSQLDelete)); 
			sbMsg.append(" }, id = "); 
			sbMsg.append(id); 
			throw new DAORuntimeException(
							sbMsg.toString(),
							ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtDelete);
		}
	}
	
	public Movie createMovie(
					final String rating, 
					final String year, 
					final String title)
	{
		if (rating == null)
		{
			throw new NullPointerException("rating parameter");
		}
		
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		if (title == null)
		{
			throw new NullPointerException("title parameter");
		}
		
		Movie result = null;
		PreparedStatement stmtInsert = null;


		StringBuffer sbInsert = new StringBuffer();
		
		try
		{
			String movie_id = MovieUtil.getUniqueMovieId(conn);
			
			sbInsert.append("INSERT INTO ");
			sbInsert.append(MovieConstants.MOVIE_TABLE_NAME);
			sbInsert.append(" ( movie_id, rating, year, title ) ");
			sbInsert.append(" VALUES (");
			sbInsert.append(movie_id);
			sbInsert.append(", ?, ?, ?) ");
			
			stmtInsert = conn.prepareStatement(sbInsert.toString());
			
			stmtInsert.setString(1, rating);
			stmtInsert.setString(2, year);
			stmtInsert.setString(3, title);
			
			log.debug("About to execute INSERT: values "
				+ rating
				+ ", "
				+ year
				+ ", "
				+ title);
				
			int rows = stmtInsert.executeUpdate();

			if (rows != 1)
			{
				StringBuffer sbMsg = new StringBuffer();
				sbMsg.append("executeUpdate returned ");
				sbMsg.append(rows);
				sbMsg.append(", sql = { "); 
				sbMsg.append(String.valueOf(sbInsert)); 
				sbMsg.append(" }"); 
				throw new DAORuntimeException(
								sbMsg.toString());
			}
			
			result = new MovieImpl(movie_id,
							rating,
							year,
							title);
			
		}
		catch (SQLException ex)
		{
			StringBuffer sbMsg = new StringBuffer();
			sbMsg.append("sql = { "); 
			sbMsg.append(String.valueOf(sbInsert)); 
			sbMsg.append(" }"); 
			throw new DAORuntimeException(
							sbMsg.toString(),
							ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtInsert);
		}
		return result;
	}

	public void updateMovie(
				final String id, 
				final String rating, 
				final String year, 
				final String title) throws MovieNotFoundException
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}
		
		if (rating == null)
		{
			throw new NullPointerException("rating parameter");
		}
		
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		if (title == null)
		{
			throw new NullPointerException("title parameter");
		}

		PreparedStatement stmtUpdate = null;
		
		try
		{
			StringBuffer sbUpdate = new StringBuffer();
			
			sbUpdate.append("UPDATE ");
			sbUpdate.append(MovieConstants.MOVIE_TABLE_NAME);
			sbUpdate.append(" SET ");
			sbUpdate.append(" rating = ?, ");
			sbUpdate.append(" year = ?, ");
			sbUpdate.append(" title = ? ");
			sbUpdate.append(" WHERE movie_id = ?");
			
			stmtUpdate = conn.prepareStatement(sbUpdate.toString());
			
			stmtUpdate.setString(1, rating);
			stmtUpdate.setString(2, year);
			stmtUpdate.setString(3, title);
			stmtUpdate.setString(4, id);
			
			int rows = stmtUpdate.executeUpdate();
			
			if (rows != 1)
			{
				StringBuffer sbMsg = new StringBuffer();
				sbMsg.append("executeUpdate returned ");
				sbMsg.append(rows);
				sbMsg.append(", id = '");
				sbMsg.append(id);
				sbMsg.append("'");
				throw new DAORuntimeException(
						sbMsg.toString());
			}
		}
		catch (SQLException ex)
		{
			StringBuffer sbMsg = new StringBuffer();
			sbMsg.append("id = "); 
			sbMsg.append(id); 
			throw new DAORuntimeException(
							sbMsg.toString(),
							ex);
		}
		finally
		{
			MovieUtil.closeStatement(stmtUpdate);
		}
	}
	
	public void close()
	{
		log.info("close() called");
		
		if ( ! isClosed() )
		{
			bIsClosed = true;
			try
			{
				if (conn != null)
				{
					MovieUtil.closeJDBCConnection(conn);
				}
			}
			finally
			{
				conn = null;
			}
			
		}
	}
	
	public boolean isClosed()
	{
		return bIsClosed;
	}
	
}
