// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieImpl.java,v 1.2 2003/08/13 04:04:23 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */

package daoexamples.movie;

/**
 * 
 * @author Sean C. Sullivan
 * 
 * @see MovieDAO
 * 
 */
class MovieImpl implements Movie
{
	private final String m_id;
	private final String m_rating;
	private final String m_year;
	private final String m_title;
	 
	public MovieImpl(final String id,
					final String rating,
					final String year,
					final String title)
	{
		if (id == null)
		{
			throw new NullPointerException("id parameter");
		}
		else if (id.length() < 1)
		{
			throw new IllegalArgumentException(
					"id parameter, value = "
					+ id);		
		}
		
		if (rating == null)
		{
			throw new NullPointerException("rating parameter");
		}
		
		if (year == null)
		{
			throw new NullPointerException("year parameter");
		}
		if (title == null)
		{
			throw new NullPointerException("title parameter");
		}
		
		m_id = id;
		m_rating = rating;
		m_year = year;
		m_title = title;		 
	}
	
	public String getId()
	{
		return m_id;
	}
	
	public String getRating()
	{
		return m_rating;
	}
	
	public String getReleaseYear()
	{
		return m_year;
	}
	
	public String getTitle()
	{
		return m_title; 
	}
	
	public String toString()
	{
		StringBuffer sbResult = new StringBuffer();
		sbResult.append("id = ");
		sbResult.append(m_id);
		sbResult.append(", title = ");
		sbResult.append(m_title);
		sbResult.append(", rating = ");
		sbResult.append(m_rating);
		sbResult.append(", year = ");
		sbResult.append(m_year);
		return sbResult.toString();
	}
}
