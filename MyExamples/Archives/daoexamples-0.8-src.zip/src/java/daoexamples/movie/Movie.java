// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/Movie.java,v 1.2 2003/08/12 04:41:01 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */
 
package daoexamples.movie;

/**
 * 
 * @author Sean C. Sullivan
 *
 */
// Note: this class does not implement java.io.Serializable,
// You might implement Serializable if you were planning  
// to pass instances of this class to an EJB  
public interface Movie
{
	public String getTitle();
	public String getRating();
	public String getReleaseYear();
	public String getId();
}
