// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieConstants.java,v 1.3 2003/08/12 04:41:01 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */
package daoexamples.movie;

/**
 * 
 * 
 * @author Sean C. Sullivan
 *
 *  
 */
final class MovieConstants
{
	static public final String MOVIE_XA_DATASOURCE_NAME = "java:comp/env/jdbc/MovieXADataSource";
	static public final String MOVIE_NONXA_DATASOURCE_NAME = "java:comp/env/jdbc/MovieNonXADataSource";
	static public final String MOVIE_TABLE_NAME = "movies";
	static public final String MOVIE_ID_SEQUENCE_NAME = "movie_id_seq";
	
	private MovieConstants()
	{
		// this constructor is intentionally private 
	}
}
