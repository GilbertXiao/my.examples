// $Header: /cvsroot/daoexamples/daoexamples/src/java/daoexamples/movie/MovieDAO.java,v 1.3 2003/08/13 04:04:23 sullis Exp $
 
/*
 * 
 *
 * 
 * 
 */
package daoexamples.movie;

import daoexamples.movie.MovieNotFoundException;

/**
 * 
 * Movie Data Access Object (DAO) 
 * 
 * <a href="http://java.sun.com/blueprints/corej2eepatterns/Patterns/DataAccessObject.html">
 * DAO pattern</a>
 *  
 * @author Sean C. Sullivan
 *
 * @see MovieDAOFactory 
 * 
 */
public interface MovieDAO
{
	/**
	 * 
	 * @param id must be non-null
	 * @return a non-null object
	 * 
	 * @throws MovieNotFoundException
	 *
	 * @see #findMoviesByYear(String)
	 *  
	 */
	public Movie findMovieById(String id)
		throws MovieNotFoundException;
	
	/**
	 * 
	 * @param year must be non-null
	 * 
	 * @return a Collection that contains zero or more {@link Movie} objects
	 * 
	 * @see #findMovieById(String)
	 * 
	 */
	public java.util.Collection findMoviesByYear(String year);
	
	/**
	 * 
	 * @param id must be non-null
	 * 
	 * @throws MovieNotFoundException
	 * 
	 * @see #createMovie(String, String, String)
	 * 
	 */
	public void deleteMovie(String id)
		throws MovieNotFoundException;
	
	/**
	 * 
	 * 
	 * @param rating must be non-null
	 * @param year must be non-null
	 * @param title must be non-null
	 * 
	 * @return a non-null {@link Movie} object
	 * 
	 * @see #deleteMovie(String)
	 * 
	 */
	public Movie createMovie(String rating, String year, String title);
	
	/**
	 * 
	 * 
	 * @param id must be non-null
	 * @param rating must be non-null
	 * @param year must be non-null
	 * @param title must be non-null
	 * 
	 * 
	 */
	public void updateMovie(String id, String rating, String year, String title)
		throws MovieNotFoundException;
		
	/**
	 * 
	 * @see #isClosed()
	 *
	 */
	public void close();
	
	/**
	 * 
	 * 
	 *  @see #close()
	 *
	 */
	public boolean isClosed();
}
