import java.io.*;

class FileCopy
{
	public static void main(String args[])
	throws IOException
	{
		FileInputStream  fis = null;
		FileOutputStream fos = null;
		try
		{
			fis = new FileInputStream(args[0]);
			fos = new FileOutputStream(args[1]);
			int x = fis.read();

			while(x != -1)
			{
				fos.write(x);
				x = fis.read();
			}
			fos.flush();
			fos.close();
			fis.close();
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("run as follows");
			System.out.println("java FileCopy <source> <dest>");
			return;
		}
		catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			return;
		}
	}
}