import java.io.*;

class WriteIntDemo
{
	public static void main(String args[]) throws IOException
	{
		FileOutputStream fos = 
			new FileOutputStream("demo.dat");

		DataOutputStream dos = 
			new DataOutputStream( fos );
		
		for(int i=1; i<11; i++)
		{
			dos.writeInt( i );
		}

		dos.flush();
		fos.flush();

		dos.close();
		fos.close();
	}
}