
import java.io.*;

class TimeTest
{
	public static void main(String args[]) throws IOException
	{
		FileInputStream fis = 
			new FileInputStream( args[0] );

		BufferedInputStream bis = 
			new BufferedInputStream( fis );

		long t1 = System.currentTimeMillis();	

		int x = bis.read();
		while( x != -1)
		{
			x = bis.read();
		}
		long t2 = System.currentTimeMillis();	

		System.out.println( t2-t1 );	

		bis.close();
		fis.close();
	}
}