
class ReadDemo 
{
	public static void main(String[] args) 
	throws java.io.IOException
	{
		int x = System.in.read();
		char c = (char)x;

		while( c != 'q' )
		{
			System.out.print( c );
			c = (char)System.in.read();
		}
	}
}
