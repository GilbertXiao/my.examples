import java.io.*;

class AddDemo 
{
	public static void main(String[] args) throws IOException
	{
		DataInputStream dis = 
			new DataInputStream(System.in);

		System.out.println("Enter a number : ");
		int a = Integer.parseInt(dis.readLine());

		System.out.println("Enter another number : ");
		int b = Integer.parseInt(dis.readLine());
				
		System.out.println("Sum : " +(a+b) );		
		
		dis.close();
	}
}