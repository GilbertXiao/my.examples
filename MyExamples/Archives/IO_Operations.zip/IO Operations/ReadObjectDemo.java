
import java.io.*;

class ReadObjectDemo 
{
	public static void main(String[] args) 
	throws Exception
	{
		FileInputStream fis = 
			new FileInputStream( "emp.ser" ); 

		ObjectInputStream ois = 
			new ObjectInputStream( fis );

		Object obj = ois.readObject();

		if(obj instanceof Employee)
		{
			Employee myEmp = (Employee)obj;
			System.out.println(myEmp.empno);
			System.out.println(myEmp.ename);
			System.out.println(myEmp.sal);
			System.out.println(myEmp.password);
		}
		else
		{
			System.out.println("Not a Employee Object");
		}
			
		ois.close();
		fis.close();
	}
}