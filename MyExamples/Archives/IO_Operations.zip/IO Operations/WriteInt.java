import java.io.*;

class WriteInt
{
	public static void main(String[] args) throws IOException
	{
		FileOutputStream fos = 
			new FileOutputStream("myint.dat");
		
		DataOutputStream dos = 
			new DataOutputStream ( fos );

		for(int i=1; i<11; i++)
			dos.writeInt(i);

		dos.close();
		fos.close();
	}
}
