import java.io.*;

class ReadIntDemo
{
	public static void main(String args[]) throws IOException
	{
		FileInputStream fis = 
			new FileInputStream("demo.dat");

		DataInputStream dis = 
			new DataInputStream( fis );
			
		for(int i=0; i<10; i++)		
		{
			System.out.println( dis.readInt() );
		}

		System.out.println( dis.readInt() );

		dis.close();
		fis.close();
	}
}