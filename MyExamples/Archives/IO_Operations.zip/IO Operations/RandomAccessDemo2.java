
import java.io.*;

class RandomAccessDemo2
{
	public static void main(String args[])
	throws IOException
	{
		RandomAccessFile raf = 
			new RandomAccessFile("demo.dat","rw");

		raf.seek( raf.length() );
		
		raf.writeBytes(	"Hello" );
		raf.close();
	}
}