
import java.io.*;

class RandomAccessDemo
{
	public static void main(String args[])
	throws IOException
	{
		RandomAccessFile raf = 
			new RandomAccessFile("demo.dat","r");

		int n = (int)( raf.length()/4 );

		for(int i=n; i>0; i--)
		{
			raf.seek( (i-1) * 4 );
			System.out.println( raf.readInt() );
		}
		raf.close();
	}
}