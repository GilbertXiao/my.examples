import java.io.*;
import java.awt.*;
import java.awt.event.*;

class FileDialogFrame extends Frame 
implements ActionListener
{
	Button open;
	FileDialog fd;
	TextArea ta;

	FileDialogFrame()
	{
		setSize(300,300);
		open = new Button("Open");
		open.addActionListener(this);

		add("North",open);
		
		ta = new TextArea();
		add("Center",ta);

		setVisible(true);
	}

	public void actionPerformed(ActionEvent evt)
	{
		if(evt.getSource() == open)
		{
			if(fd == null)
			{
				fd = new FileDialog
					(this,"Open",FileDialog.LOAD);
			}

			fd.setVisible(true);

			String fileName = fd.getFile();
			String dirName  = fd.getDirectory();

			if(fileName != null)
			{
				try	{
				FileInputStream fis = 
					new FileInputStream(dirName + fileName);

				InputStreamReader reader = 
					 new InputStreamReader(fis);

				BufferedReader br = 
					 new BufferedReader(reader);

				ta.setText("");
		
				String s = br.readLine();
				while(s != null)
				{
					ta.append(s + "\n");
					s = br.readLine();
				}
				ta.setCaretPosition(0);

				br.close();
				reader.close();
				fis.close();
			}
			catch(IOException e)
			{}

			}
		}
	}

	public static void main(String args[])
	{
		new FileDialogFrame();
	}
}