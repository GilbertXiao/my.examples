
import java.io.*;

class FileWriterDemo 
{
	public static void main(String[] args) 
	throws IOException
	{
		FileOutputStream fos = 
			new FileOutputStream("demo.txt");
		
		DataOutputStream dos = 
			new DataOutputStream( fos );

		dos.writeInt(12);
		dos.writeChar('A');
		dos.write(25);
		dos.writeDouble(12.34);

		dos.flush();
		dos.close();

		fos.flush();
		fos.close();
	}
}