
import java.io.*;

class SequenceDemo
{
	public static void main(String[] args) throws IOException
	{
		FileInputStream f1 = 
			new FileInputStream("one.txt");

		FileInputStream f2 = 
			new FileInputStream("two.txt"); 

		SequenceInputStream sis = 
				new SequenceInputStream( f1 , f2 );

		int x = sis.read();
	
		while( x != -1)
		{
			System.out.print( (char)x );
			x = sis.read();
		}

		sis.close();
		f1.close();
		f2.close();
	}
}