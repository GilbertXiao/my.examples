
import java.io.*;

class WriteObjectDemo 
{
	public static void main(String[] args) 
	throws Exception
	{
		Employee emp = new Employee();
		emp.empno = 101;
		emp.ename = "Abcd";
		emp.sal		= 12500.0F;
		
		emp.password = "secret";
		
		FileOutputStream fos = 
			new FileOutputStream( "emp.ser" ); 

		ObjectOutputStream oos = 
			new ObjectOutputStream( fos );

		oos.writeObject( emp );
		
		oos.close();
		fos.close();

		System.out.println("Object Serialzed");
	}
}
