import java.io.*;

class LineNumberDemo
{
	public static void main(String args[]) throws IOException
	{
		String toSearch = "java";

		FileReader fr = new FileReader(args[0]);

		LineNumberReader lr = 
			new LineNumberReader(fr);

		String s = lr.readLine();

		while( s != null )
		{
			s = s.toLowerCase();
			int index = s.indexOf( toSearch );
			if( index != -1 )
			{
				System.out.println( toSearch + " occurs on line : " + lr.getLineNumber() );
			}
			s = lr.readLine();
		}	
		lr.close();
		fr.close();
	}
}