import java.io.*;

class ReadLineDemo
{
	public static void main(String args[]) 
	throws IOException
	{
		InputStreamReader ir = 
			new InputStreamReader(System.in);
		
		BufferedReader br = new BufferedReader(ir);
		
		String s = br.readLine();

		while( !s.equalsIgnoreCase("quit") )
		{
			System.out.println( s );
			s = br.readLine();
		}

		br.close();
		ir.close();
	}
}