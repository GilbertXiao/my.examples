
import java.io.*;

class WriteDemo
{
	public static void main(String args[])
	throws IOException
	{
		byte[] b = {65,66,67,68,69,70};

		for(int i=0; i<b.length; i++)
		{
			System.out.write( b[i] );
		}
		System.out.write( 7 );
		System.out.write( 'X' );
		System.out.write( 'Y' );
		System.out.write( 'Z' );
		System.out.flush();
	}
}