
import java.io.*;

class PrintStreamDemo
{
	public static void main(String args[]) throws IOException
	{
		DataInputStream dis = 
			new DataInputStream(System.in);

		FileOutputStream fos = 
			new FileOutputStream(args[0]);

		PrintStream ps = new PrintStream(fos,true);

		String s = dis.readLine();

		while( !s.equalsIgnoreCase("quit") )
		{
			ps.println( s );
			s = dis.readLine();
		}

		ps.close();
		fos.close();
		dis.close();
	}
}