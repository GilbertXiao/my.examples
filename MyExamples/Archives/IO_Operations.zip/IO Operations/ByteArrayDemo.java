
import java.io.*;

class ByteArrayDemo 
{
	public static void main(String[] args) throws IOException	
	{
		byte b[] = {65,66,67,68,69,70};
		
		ByteArrayInputStream bis = 
			new ByteArrayInputStream( b );

		int x = bis.read();
		while(x != -1)
		{
			System.out.println( (char)x );
			x = bis.read();
		}
		bis.close();
	}
}