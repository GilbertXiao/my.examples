
import java.io.*;

class FileDemo
{
	public static void main(String args[])
	throws IOException
	{
		FileInputStream fis = null;

		try
		{
			fis = new FileInputStream(args[0]);
			int x = fis.read();

			while(x != -1)
			{
				System.out.print( (char)x );
				x = fis.read();
			}
		}
		catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
			return;
		}
		finally
		{
			if(fis != null)
				fis.close();
		}
	}
}