
import java.io.*;

class PrintDemo 
{
	public static void main(String[] args) throws IOException
	{
		FileOutputStream fos = 
			new FileOutputStream("demo.txt");

		PrintStream ps = 
			new PrintStream( fos, true );

		DataInputStream console = 
			new DataInputStream (System.in);

		String s = console.readLine();

		while(! s.equalsIgnoreCase("quit"))
		{
			ps.println(s);
			s = console.readLine();
		}		
		
		console.close();
		ps.flush();
		ps.close();
		fos.close();
	}
}