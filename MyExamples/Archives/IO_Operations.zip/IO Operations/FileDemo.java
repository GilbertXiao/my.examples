
import java.io.*;

class FileDemo 
{
	public static void main(String[] args) 
	{
		File f = new File(args[0]);

		System.out.println("Name : " + f.getName());
		System.out.println("Path : " + f.getAbsolutePath());
		System.out.println("exists : " + f.exists());
		System.out.println("is File: " + f.isFile());
		System.out.println("is Dir : " + f.isDirectory());
		System.out.println("read : "+ f.canRead());
		System.out.println("write: " + f.canWrite());
		System.out.println("hidden: " +f.isHidden());
	}
}