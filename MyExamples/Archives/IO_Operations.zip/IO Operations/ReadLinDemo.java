import java.io.*;

class ReadLineDemo
{
	public static void main(String[] args) throws IOException
	{		
		InputStreamReader source = 
			new InputStreamReader (System.in);

		BufferedReader br = 
			new BufferedReader(source);
		
		String s = br.readLine();

		while( !s.equalsIgnoreCase("quit") )
		{
			System.out.println(s);
			s = br.readLine();
		}

		br.close();
		source.close();
	}
}