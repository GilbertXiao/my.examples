
import java.io.*;
import java.util.Date;

class DateDemo 
{
	public static void main(String[] args) 
	{
		File f = new File(args[0]);

		long l = f.lastModified();
		Date d = new Date(l);

		int date = d.getDate();
		int month = d.getMonth();
		int year = d.getYear();

		int hh = d.getHours();
		int mm = d.getMinutes();
		int ss = d.getSeconds();

		System.out.println
			(date + "/" + (month+1) + "/" + (1900+year));

		System.out.println
			(hh + ":" + mm + ":" + ss);
	}
}
