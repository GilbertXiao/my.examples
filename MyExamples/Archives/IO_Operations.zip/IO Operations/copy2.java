
import java.io.*;

class Copy
{
	public static void main(String[] args) 
	throws IOException
	{
		FileInputStream fis = 
			new FileInputStream (args[0]);
		
		FileOutputStream fos = 
			new FileOutputStream(args[1]);

		int x = fis.read();
		
		while(x != -1)
		{
			fos.write(x);
			x = fis.read();
		}
		
		fos.close();
		fis.close();
		System.out.println("Copy successful");
	}
}