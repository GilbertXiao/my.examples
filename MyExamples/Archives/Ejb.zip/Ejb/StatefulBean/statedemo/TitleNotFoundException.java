package statedemo;

public class TitleNotFoundException 
extends Exception
{
	public TitleNotFoundException(String s)
	{
		super(s);
	}
}