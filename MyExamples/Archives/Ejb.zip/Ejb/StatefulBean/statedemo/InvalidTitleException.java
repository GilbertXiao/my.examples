package statedemo;

public class InvalidTitleException 
extends Exception
{
	public InvalidTitleException(String s)
	{
		super(s);
	}
}