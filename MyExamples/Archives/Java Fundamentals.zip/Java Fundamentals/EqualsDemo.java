
class EqualsDemo
{
	public static void main(String[] args) 
	{
		// creating object through constructor
		Point p1 = new Point(1,2);
		Point p2 = p1;

		// returns true if p1 and p2 have same instance
		boolean z = p1.equals( p2 );
		
		System.out.println(z);
	}
}
