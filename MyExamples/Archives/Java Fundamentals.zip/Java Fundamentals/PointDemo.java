
class PointDemo 
{
	public static void main(String[] args) 
	{	
		// creates object with parameterized constructor
		Point p1 = new Point(1,2);
	}
}
