class A
{
	// constructor for class A
	A()
	{
		System.out.println("Class A instantiated");
	}
}
class B
{
	// constructor for class B
	B()
	{
		System.out.println("Class B instantiated");
	}
}

class ADemo
{
	public static void main(String[] args) 
	throws Exception
	{
		// accepts through command line arguments 
		String className = args[0];
		// Class.forName searches for class at runtime
		Class c = Class.forName(className);
		// newInstance Instantiates the class and constructor is invoked 
		Object o = c.newInstance();
	}
}
