
class Factorial
{
	// recursive function
	static int getFactorial(int n)
	{
		if(n <= 1)
			return 1;
		else 
			return n * Factorial.getFactorial(n-1);
	}
}

class RecurssionDemo 
{
	public static void main(String[] args) 
	{
		// parsing string to int
		int a = Integer.parseInt( args[0] );

		int b = Factorial.getFactorial(a);

		System.out.println
				("Factorial of " + a + " = " + b); 
	}
}
