class PointUser 
{
	public static void main(String[] args) 
	{
		Point p1 = new Point();
		p1.setX(1);
		p1.setY(2);
		Point p2 = new Point();
		p2.setX(p1.getX());
		p2.setY(p1.getY());
		System.out.println( p1.equals(p2) );
		p1.show();
		p2.show();

		p1.set(5,6);
		System.out.println( p1.equals(p2) );
		System.out.println(p1);
		System.out.println(p2);

		System.out.println( p1.distance());
		System.out.println( p1.distance(p2.getX(),p2.getY()));
	}
}