/*
	This class demonstrates various functionalities of Account
*/
class Account
{
	String name;
	private float balance;

	// declares constant MIN_BALANCE which cannot be altered
	static final float MIN_BALANCE = 100.0f;

	// constructors overloaded
	// constructor used when name is specified 
	private Account(String name) 
	{
		this(name, MIN_BALANCE);
	}
	// constructor used when name and balance are specified
	private Account(String name,float balance)
	{
		this.name = name;
		this.balance = balance;
	}
	// Displays the name and balance of a account holder
	void show()
	{
		System.out.println("Name : " + this.name);
		System.out.println("Bal  : " + this.balance);
	}
	// Deposits the amount 
	void deposit(float amount)
	{
		if(amount <= 0)
		{
			System.err.println("Invalid Amount...Cannot DEPOSIT");
			return;
		}

		balance += amount;
	}
	// Withdraws the amount and checks for minimum balance
	void withdraw(float amount)
	{
		if(amount <= 0)
		{
			System.err.println("Invalid Amount...Cannot WITHDRAW");
			return;
		}

		if( (balance-amount) < MIN_BALANCE)
		{
			System.err.println("Insuffient Funds...Cannot WITHDRAW");
			return;
		}

		balance -= amount;
	}
	// Returs balance available
	float getBalance()
	{
		return this.balance;
	}
	// Creates and returns Account
	static Account createAccount(String name,float balance)
	{
		Account temp;
		
		if(name == null || balance < MIN_BALANCE )
		{
			temp = null;
		}
		else 
		{
			// Creates Account using constructor
			temp = new Account(name,balance);
		}

		return temp;
	}
}

class AccountDemo
{
	public static void main(String[] args) 
	{
	/* Calling static function using class name */
	Account a = Account.createAccount(null,200.50F); 
		
		if(a != null)
			a.show();
		else 
			System.out.println("Account Not Created");
	}
}
