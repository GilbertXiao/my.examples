
class SwapDemo 
{
	public static void main(String[] args) 
	{
		// creating objects through constructors
		Point p1 = new Point(2,4);
		Point p2 = new Point(3,7);
		// displays the values of p1 and p2
		p1.show();
		p2.show();
		// swaps the instance variables of p1 and p2
		Point.swap( p1, p2 );
		// displays the values of p1 and p2
		p1.show();
		p2.show();
	}
}
