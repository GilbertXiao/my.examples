class Point 
{
	private int x;
	private int y;
	Point()
	{
	}
	Point(int a,int b)
	{
		x = a;
		y = b;
	}
	Point(Point t)
	{
		x = t.x;
		y = t.y;
	}
	void setX(int x)
	{
		this.x = x;
	}
	int getX()
	{
		return x;
	}
	void setY(int b)
	{
		y = b;
	}
	int getY()
	{
		return y;
	}
	void set(int a,int b)
	{
		x = a;
		y = b;
	}
	public void show()
	{
		System.out.println
			( "X = " + x + " , Y = " + y	);
	}
	double distance()
	{
		return Math.sqrt( x*x + y*y );
	}
	double distance(int a,int b)
	{	
		return Math.sqrt
			(Math.pow(x-a,2) + Math.pow(y-b,2));
	}
	public String toString()
	{
		return "X = " + x + " , Y = " + y;
	}
	public boolean equals(Object o)
	{
		if(o instanceof Point)
		{
			Point t = (Point)o;
			return ( x==t.x && y == t.y);
		}
		else
		{
			return false;
		}
	}
}