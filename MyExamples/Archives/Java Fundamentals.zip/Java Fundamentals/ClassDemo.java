
class A
{
	// static block will be executed exactly once when the class is first loaded
	static
	{
		System.out.println("Class A is loaded");
	}
}

class ClassDemo 
{
	public static void main(String[] args) 
	throws ClassNotFoundException
	{
		//Class c1 = Class.forName("Xyz");	
		
		// searches the class at compile time and loads the class
		Class c1 = A.class;	
	}
}